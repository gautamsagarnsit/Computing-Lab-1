
// Adds an edge to an undirected graph
void addEdge(struct Graph* graph, int src, int dest, int weight){

    struct AdjListNode* newNode;
        
    // Add an edge from src to dest. A new node is added to the adjacency list of src at the beginning
    newNode = newAdjListNode(dest, weight);
    newNode->next = graph->array[src].head;
    graph->array[src].head = newNode;

    // add an edge from dest to src also
    newNode = newAdjListNode(src, weight);
    newNode->next = graph->array[dest].head;
    graph->array[dest].head = newNode;
}
 
 
// function to create a new adjacency list node
struct AdjListNode* newAdjListNode(int dest, int weight){
    struct AdjListNode* newNode =(struct AdjListNode*)malloc(sizeof(struct AdjListNode));
    newNode->dest = dest;
    newNode->weight = weight;
    newNode->next = NULL;
    return newNode;
}
 
// function to create a graph of V vertices
struct Graph* createGraph(int V)
{
    struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph));
    graph->V = V;
    // Create an array of adjacency lists. 
    graph->array = (struct AdjList*)calloc(V, sizeof(struct AdjList));
    // Initialize each adjacency list as empty by making head as NULL
    for (int i = 0; i < V; ++i){
        graph->array[i].head = NULL;
        graph->array[i].infected = false;
        graph->array[i].time = 0;
    }
    return graph;
}

// function to create a new Min Heap Node
struct MinHeapNode* newMinHeapNode(int v, int dist){
    struct MinHeapNode* minHeapNode = (struct MinHeapNode*)malloc(sizeof(struct MinHeapNode));
    minHeapNode->v = v;
    minHeapNode->dist = dist;
    return minHeapNode;
}
 
// function to create a Min Heap
struct MinHeap* createMinHeap(int capacity){
    struct MinHeap* minHeap =(struct MinHeap*)malloc(sizeof(struct MinHeap));
    minHeap->pos = (int *)malloc(capacity * sizeof(int));
    minHeap->size = 0;
    minHeap->capacity = capacity;
    minHeap->array = (struct MinHeapNode**)malloc(capacity * sizeof(struct MinHeapNode*));
    return minHeap;
}
 
// function to swap twonodes of min heap
void swapMinHeapNode(struct MinHeapNode** a, struct MinHeapNode** b){
    struct MinHeapNode* t = *a;
    *a = *b;
    *b = t;
}
 
// function to heapify at given idx
void minHeapify(struct MinHeap* minHeap, int idx){
    int smallest, left, right;
    smallest = idx;
    left = 2 * idx + 1;
    right = 2 * idx + 2;
    if (left < minHeap->size && minHeap->array[left]->dist < minHeap->array[smallest]->dist )
      smallest = left;
    if (right < minHeap->size && minHeap->array[right]->dist < minHeap->array[smallest]->dist )
      smallest = right;
    if (smallest != idx){
        // The nodes to be swapped in min heap
        struct MinHeapNode *smallestNode = minHeap->array[smallest];
        struct MinHeapNode *idxNode = minHeap->array[idx];
        // Swap positions
        minHeap->pos[smallestNode->v] = idx;
        minHeap->pos[idxNode->v] = smallest;
        // Swap nodes
        swapMinHeapNode(&minHeap->array[smallest], &minHeap->array[idx]);
        minHeapify(minHeap, smallest);
    }
}
 
// function to check minHeap is empty or not
int isEmpty(struct MinHeap* minHeap){
    return minHeap->size == 0;
}
 
// function to extract minimum node from heap
struct MinHeapNode* extractMin(struct MinHeap* minHeap){
    if (isEmpty(minHeap))
        return NULL;
    // Store the root node
    struct MinHeapNode* root = minHeap->array[0];
    // Replace root node with last node
    struct MinHeapNode* lastNode = minHeap->array[minHeap->size - 1];
    minHeap->array[0] = lastNode;
    // Update position of last node
    minHeap->pos[root->v] = minHeap->size-1;
    minHeap->pos[lastNode->v] = 0;
    // Reduce heap size and heapify root
    --minHeap->size;
    minHeapify(minHeap, 0);
    return root;
}
 
// function to decrease dist value of a given vertex v
void decreaseKey(struct MinHeap* minHeap, int v, int dist){
    // Get the index of v in  heap array
    int i = minHeap->pos[v];
    // Get the node and update its dist value
    minHeap->array[i]->dist = dist;
    while (i && minHeap->array[i]->dist < minHeap->array[(i - 1) / 2]->dist){
        // Swap this node with its parent
        minHeap->pos[minHeap->array[i]->v] = (i-1)/2;
        minHeap->pos[minHeap->array[(i-1)/2]->v] = i;
        swapMinHeapNode(&minHeap->array[i], &minHeap->array[(i - 1) / 2]);
        // move to parent index
        i = (i - 1) / 2;
    }
}
 
// function to check if a given vertex 'v' is in min heap or not
bool isInMinHeap(struct MinHeap *minHeap, int v){
    if (minHeap->pos[v] < minHeap->size)
        return true;
    return false;
}
 
// function used to print the solution
void printArr(int list[], int listsize){
    for (int i = 0; i < listsize; ++i)
        printf("%d\n", list[i]);
}
 
// function that calculate distances of shortest paths from src
void dijkstraFromSource(struct Graph* graph, int src, int k){    
    // number of vertices in graph
    int V = graph->V;
    int dist[V];    
    int count=0;
    int list[k];
    int idx=0;
    struct MinHeap* minHeap;
   
    // Create minHeap
    minHeap = createMinHeap(V);

    // Initialize min heap with dist value of all vertices
    for (int v = 0; v < V; ++v){
        dist[v] = INT_MAX;
        minHeap->array[v] = newMinHeapNode(v, dist[v]);
        minHeap->pos[v] = v;
    }
    // Make dist value of src vertex as 0 so that it is extracted first
    minHeap->array[src] = newMinHeapNode(src, dist[src]);
    minHeap->pos[src]   = src;
    dist[src] = 0;
    decreaseKey(minHeap, src, dist[src]);
    // Initially size of min heap is equal to V
    minHeap->size = V;
    while (!isEmpty(minHeap) && idx<k){
        // Extract the vertex with minimum distance value
        struct MinHeapNode* minHeapNode = extractMin(minHeap);
        // Store the extracted vertex number
        int u = minHeapNode->v;
        //printf("%d %d  ",u+1, src+1);
        if(u!=src && dist[u]!=INT_MAX){
            list[idx]=u+1;
            idx++;
        }
 	// Traverse through all adjacent vertices of u and update their distance values
        struct AdjListNode* pCrawl = graph->array[u].head;
        while (pCrawl != NULL){
            int v = pCrawl->dest;
            // If shortest distance to v through u is less than previously calculated distance
            if (isInMinHeap(minHeap, v) && dist[u] != INT_MAX && pCrawl->weight + dist[u] < dist[v]){
                dist[v] = dist[u] + pCrawl->weight;
                // update distance value in min heap also
                decreaseKey(minHeap, v, dist[v]);
            }
            pCrawl = pCrawl->next;
        }
    }
    // print the calculated shortest distances
    printf("The targets available are %d\n", idx);
    printArr(list, idx);
}
 
// function that calculate distances of shortest paths from target
void dijkstraFromTarget(struct Graph* graph, int target, int k){    
    // number of vertices in graph
    int V = graph->V;
    int dist[V];    
    struct MinHeap* minHeap = createMinHeap(V);
    // Initialize min heap with dist value of all vertices
    for (int v = 0; v < V; ++v){
        dist[v] = INT_MAX;
        minHeap->array[v] = newMinHeapNode(v, dist[v]);
        minHeap->pos[v] = v;
    }
    // Make dist value of src vertex as 0 so that it is extracted first
    minHeap->array[target] = newMinHeapNode(target, dist[target]);
    minHeap->pos[target] = target;
    dist[target] = 0;
    decreaseKey(minHeap, target, dist[target]);
    // Initially size of min heap is equal to V
    minHeap->size = V;
    int count=0;
    int list[k];
    int idx=0;
    while (!isEmpty(minHeap) && idx<k){
        // Extract the vertex with minimum distance value
        struct MinHeapNode* minHeapNode = extractMin(minHeap);
        // Store the extracted vertex number
        int u = minHeapNode->v;
        //printf("%d %d  ",u+1, src+1);
        if(u!=target && dist[u]!=INT_MAX && graph->array[u].infected == true && graph->array[u].time < graph->array[target].time){
            list[idx]=u+1;
            idx++;
        }
 	// Traverse through all adjacent vertices of u and update their distance values
        struct AdjListNode* pCrawl = graph->array[u].head;
        while (pCrawl != NULL){
            int v = pCrawl->dest;
            // If shortest distance to v through u is less than previously calculated distance
            if (isInMinHeap(minHeap, v) && dist[u] != INT_MAX && pCrawl->weight + dist[u] < dist[v]){
                dist[v] = dist[u] + pCrawl->weight;
                // update distance value in min heap also
                decreaseKey(minHeap, v, dist[v]);
            }
            pCrawl = pCrawl->next;
        }
    }
    // print the calculated shortest distances
    printf("The sources available are %d\n", idx);
    printArr(list, idx);
}

void printGraph(struct Graph *G){

    int noOfVertices;
    int i;
    struct AdjList *tempAdjList;
    struct AdjListNode *tempAdjListNode;

    noOfVertices = G->V;
    for(i=0;i<noOfVertices;i++){
        printf("[%d]",i+1);
        for(tempAdjListNode = G->array[i].head; tempAdjListNode!=NULL; tempAdjListNode=tempAdjListNode->next){
            printf("--%d--[%d]",tempAdjListNode->weight, tempAdjListNode->dest+1);
        
        }
        printf("\n");
    }

}



// ------------------ for part 3 ---------------------


// function to print adjacency matrix
void printMatrix(int n, int matrix[n][n]){
    int i, j, k;
    printf("\t");
    for(i=0;i<n;i++){
        printf("[%d]\t",i);
    }
    printf("\n");
    for(i=0;i<n;i++){
        printf("[%d]\t",i);
        for(j=0;j<n;j++){
            if(matrix[i][j]== INT_MAX/2)
                printf("INF\t");
            else
                printf("%d\t",matrix[i][j]);
        }
        printf("\n");
    }
}

// fucntion to create a new node
list* createNewNode(int value){
    list* new;

    new = (list *)calloc(1, sizeof(list));
    new->node = value;
    new->nextNode = NULL;

    return new;
}

void printList(list* listData){
    list*   tempList;

    for(tempList = listData; tempList!=NULL; tempList = tempList->nextNode){
        printf("[%d]--", tempList->node+1);
    }
    printf("\n");
}

bool findNodeInPath(list *pathData, int key){
    list *tempList;
    for(tempList=pathData; tempList != NULL; tempList = tempList->nextNode){
        if(tempList->node == key){
            return true;
        }
    }
    return false;
}
        
list* addToInfectionList(list *listData, int value){
    list *tempList;
    list *newNode;

    // printf("insert value [%d]\n", value);

    newNode = createNewNode(value);
    if(listData==NULL){
        listData = newNode;
        return listData;
    }
    if(findNodeInPath(listData, value) == false){
        tempList = listData;
        while(tempList->nextNode!=NULL){
            tempList = tempList->nextNode;
        }
        tempList->nextNode = newNode;
    }

    return listData;
}

int presentInInfectedList(int key, int o, int infectedNodes[o][2]){
    int i;
    int returnVal = 0;

    for( i=0; i<o; i++){
        if(infectedNodes[i][0]==key){
            returnVal =1;
            break;
        }
    }
    return returnVal;
}

//function to find shortest list
list* findPath(list* pathData, list* probablyInfectedList, int n, int o, int infectedNodes[o][2], int matrix[n][n], int src, int dest){
    list    *tempPath,
            *newNode;

    int     i, found=0;

    // printMatrix(n, matrix);
    // printf("Src, dest = [%d, %d]\n", src, dest);

    if(matrix[src][dest] == -1){
        return pathData;
    }

    pathData = createNewNode(-1);
    tempPath = pathData;
    tempPath->node = src;

    while(src != dest){
        src = matrix[src][dest];
        // printf("Updated src = [%d]\n", src);

        // create new node
        newNode = createNewNode(src); 
        
        // add the new node to list
        tempPath->nextNode = newNode;

        // move one node ahead
        tempPath = tempPath->nextNode;

        // check if the node is infected
        found = 0;
        // infectedlist stores absolute value of nodes (starting from 1, not 0)
        // hence src+1 is searched
        found = presentInInfectedList(src+1, o, infectedNodes);
        // if not infected, add to probably infected
        if(found==0){
            probablyInfectedList = addToInfectionList(probablyInfectedList, src);
        }
    }
    return probablyInfectedList;
}

// -----------------------------------------------------





