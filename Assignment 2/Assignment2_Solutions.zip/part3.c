#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include <stdbool.h>


#include "structs.h"
#include "Functions.c"

int main(int argc, char *argv[]){
    FILE *fp;
    fp = fopen(argv[1], "r");
    int n, m , src, dest, x1, x2, w, o,t;
    int i, j, k;
    
    list *pathData;
    list *probablyInfectedList=NULL;


    if(fp==NULL){
    	printf("Unable to open file");
    	return 0;
    }

    // Read values
    fscanf(fp, "%d,%d", &n, &m);

    // Declarations
    int adjacencyMatrix[n][n];
    int dist[n][n];
    int next[n][n];


    // Initialise adjacency matrix
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            if(i==j){
                adjacencyMatrix[i][j] = 0;
                next[i][j] = i;
            }
            else{
                adjacencyMatrix[i][j] = INT_MAX/2;
                next[i][j] = -1;
            }
        }
    }

    // Populate adjacency matrix
    for(i=0; i < m; i++){
    fscanf(fp, "%d,%d,%d", &x1, &x2, &w);
    	adjacencyMatrix[x1-1][x2-1] = w;
    	adjacencyMatrix[x2-1][x1-1] = w;
        next[x1-1][x2-1] = x2-1;
        next[x2-1][x1-1] = x1-1;
    }

    // create the distance matrix
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            dist[i][j] = adjacencyMatrix[i][j];
        }
    }

    // Storing infected nodes and infection time
    fscanf(fp, "%d", &o);
    int infectedNodes[o][2];
    for(i=0; i < o; i++){
    	fscanf(fp, "%d,%d", &x1, &t);
        infectedNodes[i][0] = x1;
        infectedNodes[i][1] = t;
    }
    // for(i=0;i<o;i++){
    //     printf("[%d] Infected at time [%d]\n",infectedNodes[i][0], infectedNodes[i][1]);
    // }

    // Floyd-Warshall algorithm
    for(k=0; k<n; k++){
        for(i=0; i<n; i++){
            for(j=0; j<n; j++){
                if (dist[i][k] + dist[k][j] < dist[i][j]){
                    dist[i][j] = dist[i][k] + dist[k][j];
                    next[i][j] = next[i][k];
                }
            }
        }
    }

    // find the list of probable infected nodes
    for(i=0;i<o;i++){
        for(j=i+1;j<o;j++){
            src = infectedNodes[i][0];
            dest = infectedNodes[j][0];
            pathData = NULL;
            pathData = createNewNode(-1);
            probablyInfectedList = findPath(pathData, probablyInfectedList, n, o, infectedNodes, next, src-1, dest-1);
        }
    }


    printf("List of probably infected nodes\n");
    printList(probablyInfectedList);


}





