#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include <stdbool.h>

#include "structs.h"
#include "Functions.c"
 
int main(int argc, char *argv[]){
    FILE *fp;
    fp = fopen(argv[1], "r");
    int n, m , src, k, i, x1, x2, w;
    if(fp==NULL){
    	printf("Unable to open file");
    	return 0;
    }
    fscanf(fp, "%d,%d,%d,%d", &n, &m, &src, &k);
    struct Graph* graph = createGraph(n);
    for(i=0; i < m; i++){
    fscanf(fp, "%d,%d,%d", &x1, &x2, &w);
    	addEdge(graph, x1-1, x2-1, w);
    }
    // printGraph(graph);
    dijkstraFromSource(graph, src-1, k);
    return 0;
}
    
    
    
    
    
    
    
    
    
