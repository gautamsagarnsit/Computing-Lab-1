#ifndef STRUCTS_H
#define STRUCTS_H


// data structure to represent a node in adjacency list
struct AdjListNode{
    int dest;
    int weight;
    struct AdjListNode* next;
};
 
// data structure to represent an adjacency list
struct AdjList{
   // Pointer to head node of list
   struct AdjListNode *head;
   bool infected;
   int time;
};
 
// A structure to represent a graph.
struct Graph
{
    int V;  //size of array(no of vertices)
    struct AdjList* array;   //array of adjacency list
};
 

// Structure to represent a min heap node
struct MinHeapNode{
    int  v;
    int dist;
};
 
// Structure to represent a min heap
struct MinHeap{
    // Number of heap nodes present currently
    int size;    
    // Capacity of min heap
    int capacity; 
    int *pos;   
    struct MinHeapNode **array;
};



void addEdge(struct Graph* graph, int src, int dest, int weight);
struct AdjListNode* newAdjListNode(int dest, int weight);
struct Graph* createGraph(int V);
struct MinHeapNode* newMinHeapNode(int v, int dist);
struct MinHeap* createMinHeap(int capacity);
void swapMinHeapNode(struct MinHeapNode** a, struct MinHeapNode** b);
void minHeapify(struct MinHeap* minHeap, int idx);
int isEmpty(struct MinHeap* minHeap);
struct MinHeapNode* extractMin(struct MinHeap* minHeap);
void decreaseKey(struct MinHeap* minHeap, int v, int dist);
bool isInMinHeap(struct MinHeap *minHeap, int v);
void printArr(int list[], int listsize);
bool isInMinHeap(struct MinHeap *minHeap, int v);
void printArr(int list[], int listsize);
void dijkstraFromSource(struct Graph* graph, int src, int k);
void dijkstraFromTarget(struct Graph* graph, int src, int k);
void printGraph(struct Graph *G);


// ------------------ for part 3 ---------------------
// linked list
typedef struct list_{
    int node;
    struct list_ *nextNode;
}list;


void printMatrix(int n, int matrix[n][n]);
list* createNewNode(int value);
void printList(list* listData);
bool findNodeInPath(list *pathData, int key);
list* addToInfectionList(list *listData, int value);
int presentInInfectedList(int key, int o, int infectedNodes[o][2]);
list* findPath(list* pathData, list* probablyInfectedList, int n, int o, int infectedNodes[o][2], int matrix[n][n], int src, int dest);


// -----------------------------------------------------



#endif
