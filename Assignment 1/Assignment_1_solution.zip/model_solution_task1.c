/*
Assignment 1 model solution task1.
*/
#include <stdio.h>
#include <limits.h>
#include <math.h>

typedef struct Point {
    float x, y;
} Point;

// Utillity function to calculate distance between two points
float calculateDistance(Point * p, Point * q) {
    /*
    inputs
        p: a point.
        q: a point.
    return:
        euclidean distance between these two points.
    */
    return sqrt(pow((p->x - q->x), 2) + pow((p->y-q->y), 2));
}


/* Implementation of naive algorithm*/
void search_nearest(Point * towers, Point * mobiles, int M, int N) {
    /*
    inputs
        towers: array of structure Point used to store location of towers
        mobiles: array of structure Point used to store location of mobiles
        M : no of towers
        N : no of mobiles
    output:
        Prints nearest tower for each mobile
    */
   
    // Store nearest neighbours
    int nearest_tower[N+1];
    for (int mobile = 1; mobile <= N; ++mobile) {
        // set initial value of distance
        float minDistance = calculateDistance(&mobiles[mobile], &towers[1]);
        nearest_tower[mobile] = 1;
        // For each tower calculate distance and update minDistance if needed
        for (int tower = 1; tower <= M; ++tower) {
            float distance = calculateDistance(&mobiles[mobile], &towers[tower]);
            if (minDistance > distance) {
                minDistance = distance;
                nearest_tower[mobile] = tower;
            }
        }
    }

    for (int i = 1; i <= N; ++i) {
        float d = calculateDistance(&mobiles[i], &towers[nearest_tower[i]]);
        printf("[%d] --> [%d]\n", i, nearest_tower[i]);
    }
}

int main(int argc, char * argv[]) {
    /*
        Inputs: 
            Given set of towers (size M)  and mobiles (size N)
        Outputs:
            For each mobile print the nearest tower.
        Complexity requirement:
            O(MN)
    */
    int M, N;
    FILE * fp = fopen(argv[1], "r");
    // Read input as per format
    fscanf(fp, "%d", &M);
    Point towers[M+1];
    for (int i = 1; i  <= M; ++i) {
        fscanf(fp, "%f,%f", &towers[i].x, &towers[i].y);
    }

    fscanf(fp, "%d", &N);
    Point mobiles[N+1];
    for (int i = 1; i  <= N; ++i) {
        fscanf(fp, "%f,%f", &mobiles[i].x, &mobiles[i].y);
    }

    // Naive nearest neighbours
    search_nearest(towers, mobiles, M, N);

    // Cleanup
    fclose(fp);
    return 0;
}