/*
Assignment 1 model solution task2
*/

#include <stdio.h>
#include <limits.h>
#include <math.h>

/* Structure for holding a point*/
typedef struct Point {
    float x, y;
} Point;

/* Strucure for holding the id and distance of nearest tower for a mobile */
typedef struct HT {
    int index;
    float distance;
} HT;


float calculateDistance(Point * p, Point * q) {
    /*
    inputs
        p: a point.
        q: a point.
    return:
        euclidean distance between these two points.
    */
    return sqrt(pow((p->x - q->x), 2) + pow((p->y-q->y), 2));
}

void search_nearest(Point * towers, Point * mobiles, int M, int N, HT * nearest_tower) {
    /* Inputs:
        towers: array of structure Point for storing location of towers
        mobile: array of structure Point for storing location of mobiles
        M: no of towers
        N: no of mobiles:
        neareast_tower: array of structure HT for storing nearest tower for each mobile. Function will calculate nearest tower and store details
                        in this array
      Outputs:
        Generates the nearest tower for each mobile
    */

    for (int mobile = 1; mobile <= N; ++mobile) {
        // Set initial values of minDistance and nearest towere
        float minDistance = calculateDistance(&mobiles[mobile], &towers[1]);
        nearest_tower[mobile].index = 1;
        nearest_tower[mobile].distance = minDistance;
        for (int tower = 1; tower <= M; ++tower) {
            // For each tower calculate distance from  mobile and update minDistance, nearest tower if neeeded
            float distance = calculateDistance(&mobiles[mobile], &towers[tower]);
            if (minDistance > distance) {
                minDistance = distance;
                nearest_tower[mobile].index = tower;
                nearest_tower[mobile].distance = minDistance;
            }
        }
    }
}


void incremental_nearest_search(Point * towers, Point * mobiles, 
                                 int  * ICT, int * ICM, int M, 
                                 int N, HT * nearest_tower,
                                 int * changed_towers, int m) {
    /*
        Inputs:
            towers: array of structure Point for storing location of towers
            mobiles: array of structure Point for storing location of mobiles
            M: no of towers
            N: no of mobiles
            ICT: array of integer stores whether tower i has changed location
            ICM: array of integer stores whether mobile i has changed location
            nearest_tower: Computes and stores nearest towers in this array
            changed_towers: array of integer stores location of changed towers
            m: stores the no of changed mobiles
        Output:
            Computes neareast neighbours in an optimised manner
        Complexity:
            O(nM + (N-n-x)M + xm) where
                M -> no of towers
                N -> no of mobiles
                n -> no of changed mobiles
                m -> no of changed mobiles
                x -> no of unchanged mobiles whose nearest tower didn't change location 
            Optimised in comparison to naive implementation. In Best case x = (N-n), O(nM + Nm - nm)
    */
    
    // Cases
    // Case 1: Changed mobile -> search all towers O(nM)
    // Case 2: Unchanged mobile and home tower changed -> search all towers O((N-n-x)M)
    // Case 3: Unchanged mobile and home tower not changed -> search all changed towers O((x)m)


    for (int mobile = 1; mobile <= N; ++mobile) {
        // Case 1: Changed Mobile - Search All Towers
        if (ICM[mobile] == 1) {
            // Setting initial value of minD and nearest_tower[m]
            float minD = calculateDistance(&towers[1], &mobiles[mobile]);
            nearest_tower[mobile].index = 1;
            nearest_tower[mobile].distance = minD;
            for (int tower = 1; tower <= M; ++tower) {
                // For each tower calculate distance and update minD, nearest_tower[m] if needed
                float distance = calculateDistance(&mobiles[mobile], &towers[tower]);
                if (minD > distance) {
                    minD = distance;
                    nearest_tower[mobile].index = tower;
                    nearest_tower[mobile].distance = minD;
                }
            }
        }
        else if (ICM[mobile] != 1 && ICT[nearest_tower[mobile].index] == 1) {
            // Case 2: mobile unchanged but home tower changed - search all towers
            float minD = calculateDistance(&towers[1], &mobiles[mobile]);
            nearest_tower[mobile].index = 1;
            nearest_tower[mobile].distance = minD;
            for (int tower = 1; tower <= M; ++tower) {
                float distance = calculateDistance(&mobiles[mobile], &towers[tower]);
                if (minD > distance) {
                    minD = distance;
                    nearest_tower[mobile].index = tower;
                    nearest_tower[mobile].distance = minD;
                }
            }
        } 
        else if (ICM[mobile] != 1 && ICT[nearest_tower[mobile].index] != 1) {
            // Case 3: mobile unchanged but home tower unchanded - search changed towers
            float minD = nearest_tower[mobile].distance;
            for (int changed_tower = 1; changed_tower <= m; ++changed_tower) {
                float distance = calculateDistance(&towers[changed_towers[changed_tower]], &mobiles[mobile]);
                if (minD > distance) {
                    minD = distance;
                    nearest_tower[mobile].index = changed_towers[changed_tower];
                    nearest_tower[mobile].distance = minD;
                }
            }
        }
    }
}

int main(int argc, char * argv[]) {
    /*
        Inputs: 
            Initially given set of towers (size M)  and mobiles (size N)
            Then given a set of towers (size m) which changed location and a set of mobiles (size n) which changed location
        Outputs:
            For each mobile print the nearest tower.
        Complexity requirement:
            Program should be more optimized than naive algorithm 
    */
    int M, N;
    FILE * fp = fopen(argv[1], "r");
    fscanf(fp, "%d", &M);
    Point towers[M+1];
    for (int i =1; i  <= M; ++i) {
        fscanf(fp, "%f,%f", &towers[i].x, &towers[i].y);
    }

    fscanf(fp, "%d", &N);
    Point mobiles[N+1];
    for (int i =1; i  <= N; ++i) {
        fscanf(fp, "%f,%f", &mobiles[i].x, &mobiles[i].y);
    }

    HT nearest_tower[N+1];
    // Build initial distances
    search_nearest(towers, mobiles, M, N, nearest_tower);

    int ICT[M+1]; // stores if mobile changed location
    int ICM[N+1]; // stores if tower changed location
    
    int m, n;
    // Accept changed locations of mobiles and towers
    fscanf(fp, "%d", &m);
    int changed_towers[m+1]; //stores location of changed towers
    
    for (int i = 1; i <= m; ++i) {
        int k;
        float d,e;
        fscanf(fp, "%d,%f,%f", &k, &d, &e);
        ICT[k] = 1; // update flag to store that tower changed position
        changed_towers[i] = k;
        // update location of tower
        towers[k].x = d; 
        towers[k].y = e;
    }

    fscanf(fp, "%d", &n);
    for (int i = 1; i <= n; ++i) {
        int k;
        float d,e;
        fscanf(fp, "%d,%f,%f", &k, &d, &e);
        ICM[k] = 1; // update flag to store that mobile changed position
        // update location of mobile
        mobiles[k].x = d;
        mobiles[k].y = e;
    }

    incremental_nearest_search(towers, mobiles, ICT, ICM, M, N, nearest_tower, changed_towers, m);

    for (int mobile = 1; mobile <= N; ++mobile) {
       printf("[%d] --> [%d]\n", mobile, nearest_tower[mobile].index);
    }

    // Cleanup
    fclose(fp);
    return 0;
}