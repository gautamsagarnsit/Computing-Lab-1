/*
Name : Assignment 1 Task 3
Date : 06-09-2021
Description : In this file implementation of task 3 of assignment 1 is given. KD Trees are implemented and used for efficient searching
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>

// define a large distance (infinity)
#define INF FLT_MAX

/* Structure to hold a point (mobile or tower)*/
typedef struct Point {
    float x, y;
    int id;
} Point ;

/* Structure to hold Node of the kd tree*/
typedef struct Node{
    float x, y;
    int axis;
    int id;
    struct Node * left;
    struct Node * right;
} Node;

// Caluculate distance between points
float calculateDistance(float x1, float y1, float x2, float y2) {
    return sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
}

/* Helper function to calculate absolute value of a float */
float flt_abs(float x) {
    if (x < 0)
        return -x;
    else
        return x;
}

// Order points by x coordinate
int cmp_x(Point * l, Point * r) {
    if (l-> x < r->x)
        return -1;
    else if (l->x > r->x)
        return 1;
    else
        return 0;
}

// Order points by y coordinate
int cmp_y(Point * l, Point * r) {
    if (l->y < r->y)
        return -1;
    else if (l->y > r->y)
        return 1;
    else
        return 0;
}

// Merge A[l..m] and A[m+1..r]
void merge(Point A[], int l, int m, int r, int (*fp)(Point * l, Point * r)){
    /*
        Inputs:
            A: Array of Points
            l: left end of the array
            r: right end of the array
            fp: A function pointer to compare two points in the array
        Output:
            Merges the array A[l..m] and A[m+1..r] into A[l..r]
    */
    int n1 = m-l+1; //size of left half
    int n2 = r-m; //size of right half
    
    // Temp arrays
    Point L[n1];
    Point R[n2];
    Point C[r-l+1];

    // Copy to temp arrays
    for (int i = 0; i < n1; ++i)
        L[i] = A[i+l];
    
    for (int i = 0; i < n2; ++i)
        R[i] = A[i+m+1];

    // Merge temp arrays
    int i = 0, j = 0, k = 0;
    while (i < n1 && j < n2) {
        // Use function pointer to sort by x or y coordinate as needed
        if (fp(&L[i], &R[j]) <= 0) 
            C[k++] = L[i++];
        else
            C[k++] = R[j++];
    }

    while (i < n1)
        C[k++] = L[i++];
    
    while (j < n2)
        C[k++] = R[j++];

    // Copy back to original array
    for (int a = 0; a < n1+n2; ++a)
        A[a+l] = C[a];
}

// sort A[l..r]
void mergeSort(Point  A[], int i, int j, int (*fp)(Point * l, Point * r)) {
    /* 
        Inputs:
            A : Array of points
            i : left end of the array
            j : right end of the array
            fp : pointer to function used to compare two points in aray
        Output:
            Merge sort array A[i..j] in O(N log N) time where N is the size of A
    */
    
    // If i == j base case and array is trivialy sorted (single element array)
    if (i < j) {
        int m = i + (j-i)/2;
        mergeSort(A, i, m, fp); // merge left half
        mergeSort(A, m+1, j, fp); // merge right half
        merge(A, i, m, j, fp);
    }
}

void prepare_sorting(Point * cordx, Point * cordy, int M) {
    /*
        Inputs:
            cordx: An array of points which need to be sorted according to x dimension
            cordy: An array of points which need to be sorted according to y dimension
        Outputs:
            Given unsorted cordx, cordy sort them according to x and y dimensions respectively in O(Nlog N) time. 
    */

    // Call merge sort function
    mergeSort(cordx, 0, M-1, cmp_x); // sort cordx in x 
    mergeSort(cordy, 0, M-1, cmp_y); // sort cordy in y
}

Node * create_node(float x, float y, int axis, int id) {
    /* 
        Inputs: 
            x: the value of x coordinate
            y: the valye of y coordinate
            axis: the value of the axis on which splitting is done
            id: identifier of the point
        Outputs:
            Helper function which dynamically allocates a node in heap memory and 
            initializes it as per arguments provided
    */
    
    Node * node = (Node *) malloc(sizeof(Node)); // Dynnamic Allocation
    // Initialization
    node->x = x;
    node->y = y;
    node->axis = axis;
    node->id = id;
    // Initialise pointers in the struct as well (these may be garbage values if not initialised) 
    node->left = NULL;
    node->right = NULL;
    return node;
}

Point * createAndInitialiseArray(int N) {
    /* 
        Inputs:
            N: size of the array to be created
        Outputs:
            Helper function to dynamically create and array of Points of size N in the heap memory
            and initilize all Points to 0 values
    */
    
    Point * p = (Point *) malloc(N * sizeof(Point));
    if (p == NULL) {
        printf("Insufficient memory"); // If memory not avaialable, inform and exit
        exit(1);
    }
    for (int i = 0; i < N; ++i) {
        p[i].x = 0;
        p[i].y = 0;
        p[i].id = 0;
    }
    return p;
}

Node * build_tree(Point * cordx, Point * cordy, int n,  int depth) {
    /*
        Inputs:
            cordx: An array of points sorted in x dimension
            cordy: An array of points sorted in y dimension
            n: No of points in the array
            depth: Depth of the current node in tree
        Outputs:
            Build a balanced KD tree using medians, and return the root of the tree built in O(N logn N) where N is the no of points in array
    */

    // Base case : Empty Tree
    if (n == 0)
        return NULL;

    // Base case : Leaf Node
    if (n==1) {
        Node * node = create_node(cordx[0].x, cordx[0].y, depth % 2, cordx[0].id);
        return node;
    }
    
    int axis  = depth % 2; // cycle through dimensions to split points
    int m = n/2; // middle point of sorted array which is the median

    // store count of Points in left and right subtrees
    int cleft = 0, cright = 0;

    // store median in either x or y
    float medValuex, medValuey;
    int medianId; //store id of median

    Point * leftx = createAndInitialiseArray(n);  // Points in left sub tree sorted by x coordinate
    Point * lefty = createAndInitialiseArray(n);  // Points in left sub tree sorted by y coordinate
    Point * rightx = createAndInitialiseArray(n); // Points in right sub tree sorted  by x coordinate
    Point * righty = createAndInitialiseArray(n); // Points in right sub tree sorted  by y coordinate

    if (axis == 0) {

        /* All values <= median should be in left subtree
           Finds last occurence of median in the array
           This ensures all elements in right subtree are strictly greater than node value 
           and all elements in left subtree are less than or equal to node value 
        */
        while (m+1 < n && cordx[m].x == cordx[m+1].x)
            m++;
        
        float medValue = cordx[m].x;

        // Store point with median value (node point)
        medValuex = medValue;
        medValuey = cordx[m].y;
        medianId = cordx[m].id;

        // Move all points less than or equal to median value
        for (int i = 0; i < m; ++i) {
            leftx[i] = cordx[i];
            cleft++;
        }

        // Move all points greater than (strictly) median value
        for (int i = m+1; i < n ; ++i) {
            rightx[i-(m+1)] = cordx[i];
            cright++;
        }
            
        // Move points in the non-splitting dimension  according to splitting dimension maintaining sort order (imp.)
        int d1 = 0, d2 = 0;
        for (int i = 0; i < n; ++i) {
            if(cordy[i].x < medValue)
                lefty[d1++] = cordy[i];
            else if (cordy[i].x > medValue)
                righty[d2++] = cordy[i];
            else if (cordy[i].x == medValue && cordy[i].id != cordx[m].id)
                lefty[d1++] = cordy[i];
        }
    } else {

        /* All values <= median should be in left subtree
           Finds last occurence of median in the array
           This ensures all elements in right subtree are strictly greater than node value 
           and all elements in left subtree are less than or equal to node value 
        */
        while (m+1 < n && cordy[m].y == cordy[m+1].y)
            m++;
        
        float medValue = cordy[m].y;

        // Store point with median value (node point)
        medValuex = cordy[m].x;
        medValuey = medValue;
        medianId = cordy[m].id;

        // Move all points less than or equal to median value
        for (int i = 0; i < m; ++i) {
            lefty[i] = cordy[i];
            cleft++;
        } 
            
        // Move all points greater than (strictly) median value
        for (int i = m+1; i < n ; ++i) {
            righty[i-(m+1)] = cordy[i];
            cright++;
        }

        // Move points in the non-splitting dimension  according to splitting dimension maintaining sort order (imp.)
        int d1 = 0, d2 = 0;
        for (int i = 0; i < n; ++i) {
            if(cordx[i].y < medValue) 
                leftx[d1++] = cordx[i];
            else if (cordx[i].y > medValue) 
                rightx[d2++] = cordx[i];
            else if (cordx[i].y == medValue && cordx[i].id != cordy[m].id)
                leftx[d1++] = cordx[i];
        }
    }

    // Build root
    Node * node = create_node(medValuex, medValuey, axis, medianId);
    // Build left subtree and attach
    node->left = build_tree(leftx, lefty, cleft, depth+1);
    // Build right subtree and attach
    node->right = build_tree(rightx, righty, cright, depth+1);
    
    // Cleanup
    free(leftx);
    free(lefty);
    free(rightx);
    free(righty);

    // Return root of subtree
    return node;
}

// Helper function to visualize tree
void print_tree_inorder(Node * root) {
    /*
        Inputs:
            root : root node of the tree
        Output:
            Prints the inorder traversal of tree.  Helper function to visualize tree
    */
    if (root != NULL ) {
        // Visit left child
        print_tree_inorder(root->left);
        // Print root of the subtree
        printf("(id: %d x: %f y: %f axis: %d)\n", root->id, root->x, root->y, root->axis);
        // Visit right child
        print_tree_inorder(root->right);
    }
}

// Global variables
float minD = INF; // Distance to nearest tower
Node * nearestPoint = NULL; // Pointer to nearest tower

void search_nearest(Node * root, Point * q) {
    /* 
        Inputs:
            root: the root node of the kd tree
            q: the query point
        Outputs:
            Searches the tree and returns the nearest point in tree which is nearest to query point
            Takes log (M) to find nearest point, where M is the no of nodes in tree 
    */

    // Base case
    if (root == NULL)
        return; 

    // cycle along axis with depth
    int axis = root->axis;

    /*
        Need to store selected branch and other branch so that when we backtrack we can
        visit the other node if needed 
        If during traversing we go left then selected branch = left and other = right branch
        Similarly if during traversion we go right the selected branch = right and other = left branch
    */
    Node * selectedBranch = NULL;
    Node * otherBranch = NULL;
    
    
    if (axis == 0) {
        // Node splits in x axis, select the appropriate path to a leaf node
        if (q-> x <= root->x) {
            selectedBranch = root->left;
            otherBranch = root->right;
        }
        else {
            selectedBranch = root->right;
            otherBranch = root->left;
        }
    } else {
        // Node splits in y axis, select the appropriate path to a leaf node
        if (q->y <= root->y) {
            selectedBranch = root->left;
            otherBranch = root->right;
        }
        else {
            selectedBranch = root->right;
            otherBranch = root->left;
        }
    }

    search_nearest(selectedBranch, q);

    /*
        At each node calculate distance of point(q) to current node and update current best if needed
        Also check if other side of the current node needs to be visited
        Other side of node needs to be visited if hypersphere at point q with current best distance interesects
        the spliting hyperplane at the current node.
    */
    
    // Calcualate distance of point q to node and update current best if needed
    float distance = calculateDistance(q->x, q->y, root->x, root->y);
    if (distance < minD) {
        minD = distance;
        nearestPoint = root;
    }

    // Check if the min distance hypersphere crosses splitting hyperplane in x dimension
    if (axis == 0 && flt_abs(q->x-root->x) < minD) {
        search_nearest(otherBranch, q); // visit the other branch since hypersphere intersects hyperplane
    // Check if the min distance hypersphere crosses splitting hyperplane in y dimension
    } else if (axis == 1 && flt_abs(q->y-root->y) < minD) {
        search_nearest(otherBranch, q); // visit the other branch since hypersphere intersects hyperplane
    }
}

int main(int argc, char * argv[]) {
    /*
        Inputs: 
            Given set of towers (size M)  and mobiles (size N)
        Outputs:
            For each mobile print the nearest tower.
        Complexity requirement:
            O(M log M + N log M)
    */
    
    int M, N;
    // Read input from file where filename passed as command line parameter
    FILE * fp = fopen(argv[1], "r");
    fscanf(fp, "%d", &M);
    Point towers[M]; // Store coordinates of towers
    Point cordx[M]; // Store coordinates of towers but ordered in x dimension
    Point cordy[M]; // Store coordinates of towers but ordered in y dimension

    // Accept input
    for (int i = 0; i  < M; ++i) {
        towers[i].id = i;
        fscanf(fp, "%f,%f", &towers[i].x, &towers[i].y);
        cordx[i] = towers[i];
        cordy[i] = towers[i];
    }

    fscanf(fp, "%d", &N);
    Point mobiles[N];
    for (int i = 0; i  < N; ++i) {
        mobiles[i].id = i;
        fscanf(fp, "%f,%f", &mobiles[i].x, &mobiles[i].y);
    }

    // Sort points in dimensions. Sorts should be efficient O(NLogN)
    prepare_sorting(cordx, cordy, M); // merge sort

    // Build the tree using tower points 
    Node * root = build_tree(cordx, cordy, M, 0);

    for (int mobile = 0; mobile < N; ++mobile) {
        // For each mobile find nearest tower and print
        // Before ach call to NN function initialize global vairables
        minD = INF;
        nearestPoint = NULL;
        search_nearest(root, &mobiles[mobile]);
        printf("[%d] --> [%d]\n", (mobile + 1), (nearestPoint->id + 1));
    }

    // Cleanup
    fclose(fp);
    return 0;
}